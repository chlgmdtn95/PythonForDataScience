def ft_package_add (a:int, b:int) -> int :
	return a + b